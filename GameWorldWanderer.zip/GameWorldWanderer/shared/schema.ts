import { pgTable, text, serial, integer, boolean, timestamp, json, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Game schema represents a video game with locations to guess
export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  coverImage: text("cover_image").notNull(),
  genre: text("genre").notNull(),
  locationCount: integer("location_count").notNull(),
  rating: real("rating").notNull(),
  mapImage: text("map_image").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertGameSchema = createInsertSchema(games).omit({
  id: true,
  createdAt: true,
});

// Location schema for specific places in games
export const locations = pgTable("locations", {
  id: serial("id").primaryKey(),
  gameId: integer("game_id").notNull().references(() => games.id),
  name: text("name").notNull(),
  description: text("description").notNull(),
  screenshotUrl: text("screenshot_url").notNull(),
  xCoord: real("x_coord").notNull(),
  yCoord: real("y_coord").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertLocationSchema = createInsertSchema(locations).omit({
  id: true,
  createdAt: true,
});

// Game session tracks a user playing a full game
export const gameSessions = pgTable("game_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  gameId: integer("game_id").notNull().references(() => games.id),
  totalScore: integer("total_score").default(0),
  averageDistance: real("average_distance").default(0),
  timeUsed: integer("time_used").default(0), // in seconds
  completed: boolean("completed").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

export const insertGameSessionSchema = createInsertSchema(gameSessions).omit({
  id: true,
  totalScore: true,
  averageDistance: true,
  timeUsed: true,
  completed: true,
  createdAt: true,
  completedAt: true,
});

// Round guesses for each location in a game session
export const roundGuesses = pgTable("round_guesses", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull().references(() => gameSessions.id),
  locationId: integer("location_id").notNull().references(() => locations.id),
  guessX: real("guess_x").notNull(),
  guessY: real("guess_y").notNull(),
  distance: real("distance").notNull(), // calculated distance between guess and actual
  score: integer("score").notNull(),
  timeUsed: integer("time_used").notNull(), // in seconds
  roundNumber: integer("round_number").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertRoundGuessSchema = createInsertSchema(roundGuesses).omit({
  id: true,
  createdAt: true,
});

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Game = typeof games.$inferSelect;
export type InsertGame = z.infer<typeof insertGameSchema>;

export type Location = typeof locations.$inferSelect;
export type InsertLocation = z.infer<typeof insertLocationSchema>;

export type GameSession = typeof gameSessions.$inferSelect;
export type InsertGameSession = z.infer<typeof insertGameSessionSchema>;

export type RoundGuess = typeof roundGuesses.$inferSelect;
export type InsertRoundGuess = z.infer<typeof insertRoundGuessSchema>;
