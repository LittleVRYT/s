import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Format seconds to mm:ss
export function formatTime(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}

// Calculate distance between two points on a map (normalized 0-1 coordinates)
export function calculateDistance(
  x1: number, 
  y1: number, 
  x2: number, 
  y2: number
): number {
  // Calculate Euclidean distance and scale to represent meters
  // This is a simplified version - real implementations would map to actual distances
  const scaleFactor = 1000; // Scale factor to convert to "meters"
  const dx = x2 - x1;
  const dy = y2 - y1;
  return Math.round(Math.sqrt(dx * dx + dy * dy) * scaleFactor);
}

// Calculate score based on distance
export function calculateScore(distance: number): number {
  // Closer guesses get higher scores
  // This is a basic algorithm, real implementations might have more complex scoring
  const maxScore = 1000;
  const maxDistance = 1000; // Maximum distance in "meters" to still get points
  
  if (distance >= maxDistance) {
    return 0;
  }
  
  return Math.round(maxScore * (1 - distance / maxDistance));
}

// Format large numbers with commas
export function formatNumber(num: number): string {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
