import { calculateDistance, calculateScore } from './utils';
import { Game, Location, GameSession, RoundGuess } from '@shared/schema';
import { apiRequest } from './queryClient';

export interface GameState {
  currentSession: GameSession | null;
  currentRound: number;
  rounds: RoundGuess[];
  locations: Location[];
  game: Game | null;
  isLoading: boolean;
  currentLocation: Location | null;
  roundStartTime: number | null;
}

export interface GuessResult {
  locationId: number;
  actualX: number;
  actualY: number;
  guessX: number;
  guessY: number;
  distance: number;
  score: number;
  timeUsed: number;
  roundNumber: number;
}

export class GameEngine {
  state: GameState;
  
  constructor() {
    this.state = {
      currentSession: null,
      currentRound: 0,
      rounds: [],
      locations: [],
      game: null,
      isLoading: false,
      currentLocation: null,
      roundStartTime: null
    };
  }
  
  // Initialize a new game session
  async startGame(gameId: number, userId?: number): Promise<GameSession> {
    this.state.isLoading = true;
    
    try {
      // Create a new game session
      const sessionData = {
        gameId,
        userId: userId || null
      };
      
      const response = await apiRequest('POST', '/api/sessions', sessionData);
      const session = await response.json();
      
      // Fetch game data
      const gameResponse = await fetch(`/api/games/${gameId}`);
      if (!gameResponse.ok) throw new Error('Failed to fetch game data');
      
      const game = await gameResponse.json();
      
      // Fetch locations for the game
      const locationsResponse = await fetch(`/api/games/${gameId}/locations`);
      if (!locationsResponse.ok) throw new Error('Failed to fetch locations');
      
      const locations = await locationsResponse.json();
      
      // Initialize the game state
      this.state = {
        currentSession: session,
        currentRound: 1,
        rounds: [],
        locations,
        game,
        isLoading: false,
        currentLocation: locations.length > 0 ? locations[0] : null,
        roundStartTime: Date.now()
      };
      
      return session;
    } catch (error) {
      console.error('Failed to start game:', error);
      this.state.isLoading = false;
      throw error;
    }
  }
  
  // Make a guess for the current round
  async makeGuess(guessX: number, guessY: number): Promise<GuessResult> {
    if (!this.state.currentLocation || !this.state.currentSession) {
      throw new Error('No active game session or location');
    }
    
    const roundEndTime = Date.now();
    const timeUsed = this.state.roundStartTime 
      ? Math.floor((roundEndTime - this.state.roundStartTime) / 1000) 
      : 30; // Default to 30 seconds if timer wasn't started
    
    const location = this.state.currentLocation;
    const distance = calculateDistance(guessX, guessY, location.xCoord, location.yCoord);
    const score = calculateScore(distance);
    
    // Create the guess result to return to the UI
    const guessResult: GuessResult = {
      locationId: location.id,
      actualX: location.xCoord,
      actualY: location.yCoord,
      guessX,
      guessY,
      distance,
      score,
      timeUsed,
      roundNumber: this.state.currentRound
    };
    
    try {
      // Submit the guess to the server
      const guessData = {
        sessionId: this.state.currentSession.id,
        locationId: location.id,
        guessX,
        guessY,
        distance,
        score,
        timeUsed,
        roundNumber: this.state.currentRound
      };
      
      const response = await apiRequest('POST', '/api/guesses', guessData);
      const savedGuess = await response.json();
      
      // Add the guess to our rounds
      this.state.rounds.push(savedGuess);
      
      return guessResult;
    } catch (error) {
      console.error('Error submitting guess:', error);
      throw error;
    }
  }
  
  // Advance to the next round
  nextRound(): Location | null {
    if (!this.state.game || !this.state.locations.length) {
      return null;
    }
    
    const nextRound = this.state.currentRound + 1;
    
    // Check if we have a next round
    if (nextRound > this.state.locations.length) {
      return null;
    }
    
    // Update the state for the next round
    this.state.currentRound = nextRound;
    this.state.currentLocation = this.state.locations[nextRound - 1];
    this.state.roundStartTime = Date.now();
    
    return this.state.currentLocation;
  }
  
  // Finish the game and get the final results
  async finishGame(): Promise<GameSession> {
    if (!this.state.currentSession) {
      throw new Error('No active game session');
    }
    
    try {
      // Mark the session as completed
      const updateData = {
        completed: true,
        completedAt: new Date()
      };
      
      const response = await apiRequest(
        'PATCH', 
        `/api/sessions/${this.state.currentSession.id}`, 
        updateData
      );
      
      const updatedSession = await response.json();
      this.state.currentSession = updatedSession;
      
      return updatedSession;
    } catch (error) {
      console.error('Error finishing game:', error);
      throw error;
    }
  }
  
  // Get the current round's results
  getCurrentRoundResults(): GuessResult | null {
    const roundIndex = this.state.currentRound - 1;
    if (roundIndex < 0 || roundIndex >= this.state.rounds.length) {
      return null;
    }
    
    const round = this.state.rounds[roundIndex];
    const location = this.state.locations.find(loc => loc.id === round.locationId);
    
    if (!location) return null;
    
    return {
      locationId: round.locationId,
      actualX: location.xCoord,
      actualY: location.yCoord,
      guessX: round.guessX,
      guessY: round.guessY,
      distance: round.distance,
      score: round.score,
      timeUsed: round.timeUsed,
      roundNumber: round.roundNumber
    };
  }
  
  // Get all round results
  getAllRoundResults(): GuessResult[] {
    return this.state.rounds.map(round => {
      const location = this.state.locations.find(loc => loc.id === round.locationId);
      
      if (!location) {
        throw new Error(`Location with id ${round.locationId} not found`);
      }
      
      return {
        locationId: round.locationId,
        actualX: location.xCoord,
        actualY: location.yCoord,
        guessX: round.guessX,
        guessY: round.guessY,
        distance: round.distance,
        score: round.score,
        timeUsed: round.timeUsed,
        roundNumber: round.roundNumber
      };
    });
  }
}

// Create a singleton instance
export const gameEngine = new GameEngine();
