import { Game } from "@shared/schema";

// These are just for client-side typing, the actual data comes from the API
export interface GameWithImageUrl extends Game {
  coverImageUrl: string;
  mapImageUrl: string;
}

// Map data for references - data actually comes from API
export const GAME_ID = {
  WITCHER3: 1,
  SKYRIM: 2,
  GTA5: 3
};
