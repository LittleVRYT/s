import { Location } from "@shared/schema";
import { GAME_ID } from "./games";

// These are just for client-side reference, the actual data comes from the API
export const LOCATION_IDS = {
  // Witcher 3 Locations
  NOVIGRAD_HARBOR: 1,
  CROWS_PERCH: 2,
  KAER_MORHEN: 3,
  SKELLIGE_ISLES: 4,
  WHITE_ORCHARD: 5,
};
