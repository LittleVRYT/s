import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import GameCard from "@/components/game/game-card";
import { Game } from "@shared/schema";

const Home = () => {
  const { data: games, isLoading, error } = useQuery<Game[]>({
    queryKey: ['/api/games'],
  });

  return (
    <section className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-5xl font-bold mb-4 text-primary font-['Orbitron']">
          Locate. Guess. Conquer.
        </h2>
        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
          Test your knowledge of video game worlds! Identify locations from screenshots and pin them on the map.
        </p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="bg-card rounded-xl overflow-hidden shadow-lg animate-pulse">
              <div className="h-48 bg-muted"></div>
              <div className="p-4">
                <div className="h-6 bg-muted rounded mb-3"></div>
                <div className="h-10 bg-muted rounded"></div>
              </div>
            </div>
          ))}
        </div>
      ) : error ? (
        <div className="text-center p-8 bg-card rounded-lg mb-16">
          <h3 className="text-xl font-bold text-destructive mb-2">Error loading games</h3>
          <p className="text-muted-foreground">Please try again later</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {games?.map((game) => (
            <GameCard key={game.id} game={game} />
          ))}
        </div>
      )}

      <div className="text-center">
        <Button 
          variant="outline" 
          size="lg"
          className="bg-card text-foreground hover:bg-card/80 px-6 py-3 text-lg"
        >
          View All Games <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </section>
  );
};

export default Home;
