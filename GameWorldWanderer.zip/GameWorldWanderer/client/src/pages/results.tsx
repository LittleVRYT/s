import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { 
  Home, 
  Share2, 
  RefreshCw 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatTime, formatNumber } from "@/lib/utils";
import { GameSession, RoundGuess, Game, Location } from "@shared/schema";
import { Leaderboard } from "@/components/game/leaderboard";

const Results = () => {
  const [, setLocation] = useLocation();
  const [, params] = useRoute<{ sessionId: string }>("/results/:sessionId");
  const sessionId = Number(params?.sessionId);

  // Fetch session data
  const { data: session, isLoading: isSessionLoading } = useQuery<GameSession>({
    queryKey: [`/api/sessions/${sessionId}`],
    enabled: !!sessionId && !isNaN(sessionId),
  });

  // Fetch game data if we have a session
  const { data: game, isLoading: isGameLoading } = useQuery<Game>({
    queryKey: [`/api/games/${session?.gameId}`],
    enabled: !!session?.gameId,
  });

  // Fetch guesses for the session
  const { data: guesses, isLoading: isGuessesLoading } = useQuery<RoundGuess[]>({
    queryKey: [`/api/sessions/${sessionId}/guesses`],
    enabled: !!sessionId && !isNaN(sessionId),
  });

  // Fetch locations for the game to get location names
  const { data: locations, isLoading: isLocationsLoading } = useQuery<Location[]>({
    queryKey: [`/api/games/${session?.gameId}/locations`],
    enabled: !!session?.gameId,
  });

  const isLoading = isSessionLoading || isGameLoading || isGuessesLoading || isLocationsLoading;

  // Get location name by ID
  const getLocationName = (locationId: number): string => {
    const location = locations?.find(loc => loc.id === locationId);
    return location?.name || "Unknown Location";
  };

  // Handle play again button
  const handlePlayAgain = () => {
    if (game) {
      setLocation(`/game/${game.id}`);
    }
  };

  // Handle share results button
  const handleShareResults = () => {
    if (!session || !game) return;
    
    const shareText = `I scored ${session.totalScore} points in ${game.name} on GameLocator! Can you beat my score?`;
    
    if (navigator.share) {
      navigator.share({
        title: 'My GameLocator Score',
        text: shareText,
        url: window.location.href,
      });
    } else {
      // Fallback to clipboard copy
      navigator.clipboard.writeText(shareText + ' ' + window.location.href);
      alert("Results copied to clipboard!");
    }
  };

  // Handle go home button
  const handleGoHome = () => {
    setLocation('/');
  };

  // If loading, show loading state
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 flex items-center justify-center h-[60vh]">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="animate-spin mb-4 mx-auto w-12 h-12 border-4 border-primary border-t-transparent rounded-full"></div>
            <h2 className="text-xl font-bold">Loading Results...</h2>
          </CardContent>
        </Card>
      </div>
    );
  }

  // If no data found, show error
  if (!session || !game || !guesses || !locations) {
    return (
      <div className="container mx-auto px-4 py-8 flex items-center justify-center h-[60vh]">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <h2 className="text-xl font-bold text-destructive">Results Not Found</h2>
            <p className="text-muted-foreground mt-2">Sorry, we couldn't find the results you're looking for.</p>
            <Button className="mt-4" onClick={handleGoHome}>Go Home</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <section className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <Card className="overflow-hidden shadow-xl">
          <div className="p-6 bg-primary">
            <h2 className="text-3xl font-['Orbitron'] text-white text-center">Game Results</h2>
          </div>
          
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card className="bg-background">
                <CardContent className="p-4 text-center">
                  <div className="text-4xl font-bold text-emerald-500 mb-2">
                    {formatNumber(session.totalScore || 0)}
                  </div>
                  <div className="text-muted-foreground">Total Score</div>
                </CardContent>
              </Card>
              <Card className="bg-background">
                <CardContent className="p-4 text-center">
                  <div className="text-4xl font-bold text-primary mb-2">
                    {Math.round(session.averageDistance || 0)}
                  </div>
                  <div className="text-muted-foreground">Avg. Distance (m)</div>
                </CardContent>
              </Card>
              <Card className="bg-background">
                <CardContent className="p-4 text-center">
                  <div className="text-4xl font-bold text-amber-500 mb-2">
                    {formatTime(session.timeUsed || 0)}
                  </div>
                  <div className="text-muted-foreground">Time Used</div>
                </CardContent>
              </Card>
            </div>
            
            {/* Rounds Summary */}
            <div className="mb-8">
              <h3 className="text-xl font-['Orbitron'] mb-4">Round Summary</h3>
              <Card className="bg-background overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Round</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead className="text-right">Distance</TableHead>
                      <TableHead className="text-right">Time</TableHead>
                      <TableHead className="text-right">Score</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {guesses.map((guess) => (
                      <TableRow key={guess.id}>
                        <TableCell>{guess.roundNumber}</TableCell>
                        <TableCell>{getLocationName(guess.locationId)}</TableCell>
                        <TableCell className="text-right">{guess.distance}m</TableCell>
                        <TableCell className="text-right">{formatTime(guess.timeUsed)}</TableCell>
                        <TableCell className="text-right font-medium text-emerald-500">
                          {guess.score}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
            </div>
            
            {/* Leaderboard */}
            <div className="mb-8">
              <h3 className="text-xl font-['Orbitron'] mb-4">Leaderboard</h3>
              <Leaderboard gameId={game.id} />
            </div>
            
            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button 
                onClick={handlePlayAgain}
                className="bg-primary hover:bg-primary/90"
              >
                <RefreshCw className="mr-2 h-4 w-4" /> Play Again
              </Button>
              <Button
                variant="secondary"
                onClick={handleShareResults}
              >
                <Share2 className="mr-2 h-4 w-4" /> Share Results
              </Button>
              <Button
                variant="outline"
                onClick={handleGoHome}
              >
                <Home className="mr-2 h-4 w-4" /> Home
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

export default Results;
