import { useState, useEffect, useCallback } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Search, RefreshCw, X, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { GuessResult, gameEngine } from "@/lib/game-engine";
import { Game as GameType, Location, GameSession } from "@shared/schema";
import GameMap from "@/components/game/game-map";
import IframeMap from "@/components/game/iframe-map";
import RoundResultModal from "@/components/game/round-result-modal";
import { formatTime } from "@/lib/utils";

const GamePage = () => {
  const [, setLocation] = useLocation();
  const [, params] = useRoute<{ gameId: string }>("/game/:gameId");
  const gameId = Number(params?.gameId);

  const [session, setSession] = useState<GameSession | null>(null);
  const [currentRound, setCurrentRound] = useState<number>(0);
  const [currentLocation, setCurrentLocation] = useState<Location | null>(null);
  const [isGuessing, setIsGuessing] = useState<boolean>(false);
  const [hasSelectedLocation, setHasSelectedLocation] = useState<boolean>(false);
  const [guessCoords, setGuessCoords] = useState<{ x: number, y: number } | null>(null);
  const [roundResult, setRoundResult] = useState<GuessResult | null>(null);
  const [showResultModal, setShowResultModal] = useState<boolean>(false);
  const [timer, setTimer] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Fetch game data
  const { data: game } = useQuery<GameType>({
    queryKey: [`/api/games/${gameId}`],
    enabled: !!gameId && !isNaN(gameId),
  });

  // Initialize game session
  useEffect(() => {
    if (!gameId || isNaN(gameId)) return;

    const initGame = async () => {
      try {
        setIsLoading(true);
        const newSession = await gameEngine.startGame(gameId);
        setSession(newSession);
        setCurrentRound(1);
        setCurrentLocation(gameEngine.state.currentLocation);
        setIsLoading(false);
      } catch (error) {
        console.error("Failed to initialize game:", error);
        setIsLoading(false);
      }
    };

    initGame();
  }, [gameId]);

  // Handle timer
  useEffect(() => {
    if (!currentLocation || showResultModal) return;
    
    const interval = setInterval(() => {
      setTimer((prev) => prev + 1);
    }, 1000);
    
    return () => clearInterval(interval);
  }, [currentLocation, showResultModal]);

  // Handle map click for guessing
  const handleMapClick = useCallback((x: number, y: number) => {
    console.log("Map clicked at:", x, y);
    if (!isGuessing) {
      setGuessCoords({ x, y });
      setHasSelectedLocation(true);
    }
  }, [isGuessing]);

  // Submit guess
  const handleSubmitGuess = useCallback(async () => {
    if (!guessCoords || !currentLocation) return;

    try {
      setIsGuessing(true);
      const result = await gameEngine.makeGuess(guessCoords.x, guessCoords.y);
      setRoundResult(result);
      setShowResultModal(true);
    } catch (error) {
      console.error("Error submitting guess:", error);
    } finally {
      setIsGuessing(false);
    }
  }, [guessCoords, currentLocation]);

  // Reset the current guess
  const handleResetGuess = useCallback(() => {
    setGuessCoords(null);
    setHasSelectedLocation(false);
  }, []);

  // Handle next round
  const handleNextRound = useCallback(async () => {
    setShowResultModal(false);
    setRoundResult(null);
    setGuessCoords(null);
    setHasSelectedLocation(false);
    setTimer(0);
    
    const nextLocation = gameEngine.nextRound();
    
    if (nextLocation) {
      setCurrentRound(gameEngine.state.currentRound);
      setCurrentLocation(nextLocation);
    } else {
      // End of game, finalize session and redirect to results
      try {
        const finalizedSession = await gameEngine.finishGame();
        setLocation(`/results/${finalizedSession.id}`);
      } catch (error) {
        console.error("Error finalizing game:", error);
      }
    }
  }, [setLocation]);

  // Handle exit game
  const handleExitGame = useCallback(() => {
    setLocation('/');
  }, [setLocation]);

  // If loading, show loading state
  if (isLoading || !game || !currentLocation) {
    return (
      <div className="container mx-auto px-4 py-8 flex items-center justify-center h-[60vh]">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="animate-spin mb-4 mx-auto w-12 h-12 border-4 border-primary border-t-transparent rounded-full"></div>
            <h2 className="text-xl font-bold">Loading Game...</h2>
            <p className="text-muted-foreground mt-2">Preparing your adventure</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Check if current round is the last round
  const isLastRound = currentRound === game.locationCount;

  return (
    <section className="container mx-auto px-4 py-6 h-full flex flex-col">
      {/* Game Header */}
      <Card className="mb-4">
        <CardContent className="p-4 flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <img 
              src={game.coverImage}
              alt={`${game.name} thumbnail`}
              className="w-12 h-12 rounded-md object-cover mr-4"
            />
            <div>
              <h2 className="text-xl font-['Orbitron'] text-primary">{game.name}</h2>
              <div className="flex text-sm text-muted-foreground">
                <span className="mr-4">Round {currentRound}/{game.locationCount}</span>
                <span>Score: {gameEngine.state.rounds.reduce((sum, round) => sum + round.score, 0)}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Timer */}
            <div className="bg-background rounded-lg px-4 py-2 flex items-center">
              <Clock className="text-amber-500 mr-2 h-5 w-5" />
              <span className="font-mono text-xl">{formatTime(timer)}</span>
            </div>
            
            {/* Exit Button */}
            <Button variant="outline" onClick={handleExitGame}>
              <X className="mr-1 h-4 w-4" /> Exit
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Main Game Area */}
      <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Screenshot Area */}
        <Card className="overflow-hidden flex flex-col">
          <div className="flex-1 relative">
            <img 
              src={currentLocation.screenshotUrl}
              alt={`Screenshot from ${game.name}`}
              className="w-full h-full object-cover"
            />
            
            {/* Magnifying glass overlay */}
            <div className="absolute bottom-4 right-4 bg-background/80 rounded-full p-2">
              <Search className="h-5 w-5" />
            </div>
          </div>
          <CardContent className="p-4 border-t border-background">
            <p className="text-muted-foreground text-center">
              Where is this location in {game.name}?
            </p>
          </CardContent>
        </Card>

        {/* Map Area */}
        <Card className="overflow-hidden flex flex-col">
          <div className="flex-1 relative">
            {gameId === 3 ? (
              /* GTA V Interactive Map */
              <IframeMap
                iframeContent='<iframe src="https://gta-5-map.com?embed=light" height="500" style="position: relative; width: 100%;"></iframe>'
                onClick={handleMapClick}
                disabled={isGuessing}
                markers={guessCoords ? [
                  {
                    x: guessCoords.x,
                    y: guessCoords.y,
                    color: 'rgb(249, 115, 22)',
                    isUser: true,
                    pulse: true
                  }
                ] : []}
              />
            ) : (
              /* Regular Game Map */
              <GameMap
                mapImage={game.mapImage}
                onClick={handleMapClick}
                markers={guessCoords ? [
                  {
                    x: guessCoords.x,
                    y: guessCoords.y,
                    color: 'rgb(249, 115, 22)',
                    isUser: true,
                    pulse: true
                  }
                ] : []}
                disabled={isGuessing}
              />
            )}
          </div>
          <CardContent className="p-4 border-t border-background flex justify-between items-center">
            <Button 
              variant="outline" 
              onClick={handleResetGuess}
              disabled={!hasSelectedLocation || isGuessing}
            >
              <RefreshCw className="mr-1 h-4 w-4" /> Reset
            </Button>
            <Button 
              variant="default" 
              className="bg-amber-500 hover:bg-amber-600 text-white"
              onClick={handleSubmitGuess}
              disabled={!hasSelectedLocation || isGuessing}
            >
              Make Guess
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Round Result Modal */}
      <RoundResultModal
        open={showResultModal}
        onClose={() => setShowResultModal(false)}
        result={roundResult}
        location={currentLocation}
        mapImage={game.mapImage}
        onNextRound={handleNextRound}
        isFinalRound={isLastRound}
      />
    </section>
  );
};

export default GamePage;
