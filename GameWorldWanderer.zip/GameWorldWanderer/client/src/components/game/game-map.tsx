import { useRef, useEffect, useState, useCallback } from "react";
import { Plus, Minus } from "lucide-react";
import { Button } from "@/components/ui/button";

interface GameMapProps {
  mapImage: string;
  onClick: (x: number, y: number) => void;
  markers?: Array<{
    x: number;
    y: number;
    color: string;
    isUser?: boolean;
    pulse?: boolean;
  }>;
  lines?: Array<{
    x1: number;
    y1: number;
    x2: number;
    y2: number;
    color: string;
  }>;
  disabled?: boolean;
}

const GameMap = ({ 
  mapImage, 
  onClick, 
  markers = [], 
  lines = [],
  disabled = false 
}: GameMapProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(1);
  const [image, setImage] = useState<HTMLImageElement | null>(null);
  const [userMarker, setUserMarker] = useState<{ x: number, y: number } | null>(null);

  // Load the map image
  useEffect(() => {
    const img = new Image();
    img.src = mapImage;
    img.onload = () => setImage(img);
  }, [mapImage]);

  // Draw the map and markers
  const drawMap = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx || !image) return;

    const { width, height } = canvas;
    
    // Clear canvas
    ctx.clearRect(0, 0, width, height);
    
    // Draw map image
    ctx.drawImage(image, 0, 0, width, height);
    
    // Draw lines
    lines.forEach(line => {
      ctx.beginPath();
      ctx.moveTo(line.x1 * width, line.y1 * height);
      ctx.lineTo(line.x2 * width, line.y2 * height);
      ctx.strokeStyle = line.color;
      ctx.lineWidth = 2;
      ctx.stroke();
    });
    
    // Draw markers
    markers.forEach(marker => {
      ctx.beginPath();
      ctx.arc(marker.x * width, marker.y * height, 12, 0, Math.PI * 2);
      ctx.fillStyle = marker.color;
      ctx.fill();
      ctx.strokeStyle = 'white';
      ctx.lineWidth = 2;
      ctx.stroke();
    });
    
    // Draw user marker if set
    if (userMarker) {
      ctx.beginPath();
      ctx.arc(userMarker.x * width, userMarker.y * height, 12, 0, Math.PI * 2);
      ctx.fillStyle = 'rgb(249, 115, 22)'; // Orange color
      ctx.fill();
      ctx.strokeStyle = 'white';
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  }, [image, markers, lines, userMarker]);

  // Handle resize
  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current && canvasRef.current) {
        const { width, height } = containerRef.current.getBoundingClientRect();
        canvasRef.current.width = width;
        canvasRef.current.height = height;
        drawMap();
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [drawMap]);

  // Redraw when dependencies change
  useEffect(() => {
    drawMap();
  }, [drawMap, zoom, image, markers, lines]);

  // Handle map click
  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (disabled) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / canvas.width;
    const y = (e.clientY - rect.top) / canvas.height;
    
    setUserMarker({ x, y });
    onClick(x, y);
  };

  // Zoom in/out
  const handleZoom = (direction: 'in' | 'out') => {
    setZoom(prev => {
      const newZoom = direction === 'in' ? prev + 0.1 : prev - 0.1;
      return Math.max(0.5, Math.min(2, newZoom));
    });
  };

  return (
    <div className="w-full h-full relative" ref={containerRef}>
      <canvas
        ref={canvasRef}
        onClick={handleClick}
        className={`w-full h-full ${disabled ? 'cursor-default' : 'cursor-pointer'}`}
        style={{ transform: `scale(${zoom})`, transformOrigin: 'center' }}
      />
      
      {/* Map controls */}
      <div className="absolute bottom-4 right-4 flex flex-col space-y-2">
        <Button
          size="icon"
          variant="secondary"
          className="rounded-full bg-background/80 hover:bg-background"
          onClick={() => handleZoom('in')}
        >
          <Plus className="h-4 w-4" />
        </Button>
        <Button
          size="icon"
          variant="secondary"
          className="rounded-full bg-background/80 hover:bg-background"
          onClick={() => handleZoom('out')}
        >
          <Minus className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};

export default GameMap;
