import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, MapPin, Star } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Game } from "@shared/schema";

interface GameCardProps {
  game: Game;
}

const GameCard = ({ game }: GameCardProps) => {
  return (
    <Card className="bg-card overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
      <div className="h-48 bg-muted relative">
        <img 
          src={game.coverImage} 
          alt={`${game.name} landscape`} 
          className="w-full h-full object-cover"
        />
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background/90 to-transparent p-4">
          <h3 className="text-xl font-['Orbitron'] text-foreground">{game.name}</h3>
        </div>
      </div>
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-3">
          <div className="flex items-center">
            <Badge variant="outline" className="bg-emerald-500/20 text-emerald-500 hover:bg-emerald-500/20 hover:text-emerald-500">
              {game.genre}
            </Badge>
            <span className="ml-2 text-sm text-muted-foreground flex items-center">
              <MapPin className="h-3 w-3 mr-1" /> {game.locationCount} locations
            </span>
          </div>
          <div className="text-sm text-muted-foreground flex items-center">
            <Star className="h-3 w-3 mr-1 text-amber-500" /> {game.rating.toFixed(1)}
          </div>
        </div>
        <div className="flex justify-between items-center">
          <Link href={`/game/${game.id}`}>
            <Button className="bg-primary hover:bg-primary/90 text-white">
              Play Game
            </Button>
          </Link>
          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary">
            <Heart className="h-5 w-5" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default GameCard;
