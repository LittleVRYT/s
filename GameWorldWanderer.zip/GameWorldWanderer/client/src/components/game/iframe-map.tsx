import React, { useRef, useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Minus, Plus, MousePointer, Move } from 'lucide-react';

interface IframeMapProps {
  iframeContent: string;
  onClick: (x: number, y: number) => void;
  disabled?: boolean;
  markers?: Array<{
    x: number;
    y: number;
    color: string;
    isUser?: boolean;
    pulse?: boolean;
  }>;
}

const IframeMap: React.FC<IframeMapProps> = ({ 
  iframeContent, 
  onClick, 
  disabled = false,
  markers = []
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(1);
  const [clickPosition, setClickPosition] = useState<{x: number, y: number} | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [startPoint, setStartPoint] = useState({ x: 0, y: 0 });
  const [mode, setMode] = useState<'click' | 'pan'>('click');
  
  // Handle zoom in/out
  const handleZoom = (direction: 'in' | 'out') => {
    setZoom(prev => {
      if (direction === 'in') {
        return Math.min(prev + 0.1, 2);
      } else {
        return Math.max(prev - 0.1, 0.5);
      }
    });
  };

  // Toggle between click and pan modes
  const toggleMode = () => {
    setMode(prev => prev === 'click' ? 'pan' : 'click');
  };

  // Handle mouse down for dragging
  const handleMouseDown = (e: React.MouseEvent) => {
    if (disabled || mode !== 'pan') return;
    
    e.preventDefault();
    setIsDragging(true);
    setStartPoint({ x: e.clientX - position.x, y: e.clientY - position.y });
  };

  // Handle mouse move for dragging
  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || mode !== 'pan') return;
    
    e.preventDefault();
    const newX = e.clientX - startPoint.x;
    const newY = e.clientY - startPoint.y;
    setPosition({ x: newX, y: newY });
  };

  // Handle mouse up to end dragging
  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Handle click on the iframe container
  const handleClick = (e: React.MouseEvent) => {
    if (disabled || mode !== 'click') return;
    
    // Prevent default behavior
    e.preventDefault();
    
    const container = containerRef.current;
    if (!container) return;
    
    // Get container dimensions and click position
    const rect = container.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    
    // Store click position for marker rendering
    setClickPosition({ x, y });
    
    // Call the parent component's onClick handler
    onClick(x, y);
  };
  
  // Add mouse up event listener to document
  useEffect(() => {
    const handleGlobalMouseUp = () => {
      setIsDragging(false);
    };
    
    document.addEventListener('mouseup', handleGlobalMouseUp);
    return () => {
      document.removeEventListener('mouseup', handleGlobalMouseUp);
    };
  }, []);
  
  // Clear existing markers when receiving new ones from parent
  useEffect(() => {
    if (markers.length > 0) {
      setClickPosition(null);
    }
  }, [markers]);

  // Function to render markers
  const renderMarkers = () => {
    if (!containerRef.current) return null;
    
    const allMarkers = [...markers];
    
    // Add the user's click marker if it exists
    if (clickPosition && !disabled) {
      allMarkers.push({
        x: clickPosition.x,
        y: clickPosition.y,
        color: 'rgb(249, 115, 22)', // Orange color
        isUser: true,
        pulse: true
      });
    }
    
    return allMarkers.map((marker, index) => {
      const markerSize = marker.isUser ? 20 : 16;
      
      return (
        <div
          key={`marker-${index}`}
          className={`absolute rounded-full ${marker.pulse ? 'animate-pulse' : ''}`}
          style={{
            left: `${marker.x * 100}%`,
            top: `${marker.y * 100}%`,
            width: `${markerSize}px`,
            height: `${markerSize}px`,
            backgroundColor: marker.color,
            transform: 'translate(-50%, -50%)',
            border: '2px solid white',
            boxShadow: '0 0 0 2px rgba(0, 0, 0, 0.3)',
            zIndex: 1000
          }}
        />
      );
    });
  };

  return (
    <div 
      className="w-full h-full relative" 
      ref={containerRef} 
      style={{ overflow: 'hidden' }}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onClick={handleClick}
    >
      {/* Iframe container */}
      <div 
        dangerouslySetInnerHTML={{ __html: iframeContent }} 
        style={{ 
          transform: `scale(${zoom}) translate(${position.x / zoom}px, ${position.y / zoom}px)`, 
          transformOrigin: 'center',
          height: '100%',
          width: '100%',
          transition: isDragging ? 'none' : 'transform 0.1s ease',
          pointerEvents: 'none' // Always set to none to prevent iframe from capturing clicks
        }}
      />
      
      {/* Render all markers */}
      {renderMarkers()}
      
      {/* Map controls */}
      <div className="absolute bottom-4 right-4 flex flex-col space-y-2 z-50">
        <Button
          size="icon"
          variant="secondary"
          className="rounded-full bg-background/80 hover:bg-background"
          onClick={(e) => {
            e.stopPropagation();
            toggleMode();
          }}
          title={mode === 'click' ? "Switch to Pan Mode" : "Switch to Click Mode"}
        >
          {mode === 'click' ? (
            <MousePointer className="h-4 w-4" />
          ) : (
            <Move className="h-4 w-4" />
          )}
        </Button>
        <Button
          size="icon"
          variant="secondary"
          className="rounded-full bg-background/80 hover:bg-background"
          onClick={(e) => {
            e.stopPropagation();
            handleZoom('in');
          }}
          title="Zoom In"
        >
          <Plus className="h-4 w-4" />
        </Button>
        <Button
          size="icon"
          variant="secondary"
          className="rounded-full bg-background/80 hover:bg-background"
          onClick={(e) => {
            e.stopPropagation();
            handleZoom('out');
          }}
          title="Zoom Out"
        >
          <Minus className="h-4 w-4" />
        </Button>
      </div>
      
      {/* Mode indicator */}
      <div className="absolute top-4 right-4 bg-background/80 rounded-md px-3 py-1 text-sm z-50 flex items-center">
        <span className="mr-2">Mode:</span>
        {mode === 'click' ? (
          <span className="text-amber-500 font-medium flex items-center">
            <MousePointer className="h-3 w-3 mr-1" /> Place Marker
          </span>
        ) : (
          <span className="text-blue-500 font-medium flex items-center">
            <Move className="h-3 w-3 mr-1" /> Pan Map
          </span>
        )}
      </div>
    </div>
  );
};

export default IframeMap;