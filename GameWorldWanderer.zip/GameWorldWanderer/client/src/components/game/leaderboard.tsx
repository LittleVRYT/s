import { useQuery } from "@tanstack/react-query";
import { GameSession, User } from "@shared/schema";
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { formatNumber, formatTime } from "@/lib/utils";
import { Trophy, Medal, Clock, Wifi, WifiOff } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useLeaderboardSocket } from "@/hooks/use-leaderboard-socket";

interface LeaderboardProps {
  gameId: number;
  className?: string;
}

export function Leaderboard({ gameId, className }: LeaderboardProps) {
  // Set up real-time WebSocket connection for this game's leaderboard
  const { isConnected, error: socketError } = useLeaderboardSocket(gameId);
  
  // Fetch leaderboard data
  const { data: leaderboard, isLoading, error } = useQuery<GameSession[]>({
    queryKey: [`/api/games/${gameId}/leaderboard`],
    // Refetch data every minute to ensure we're up to date even if WebSockets fail
    refetchInterval: 60000,
  });

  if (isLoading) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            <span>Loading Leaderboard...</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="text-destructive">Error Loading Leaderboard</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Unable to load leaderboard data. Please try again later.</p>
        </CardContent>
      </Card>
    );
  }

  if (!leaderboard || leaderboard.length === 0) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            <span>Leaderboard</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center py-8 text-muted-foreground">No scores recorded yet. Be the first to play!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={className}>
      <CardHeader className="space-y-1">
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            <span>Top Scores</span>
          </CardTitle>
          
          {/* Live connection indicator */}
          <Badge 
            variant={isConnected ? "default" : "outline"} 
            className={`text-xs ${isConnected ? "bg-green-600" : "text-muted-foreground"}`}
          >
            {isConnected ? 
              <><Wifi className="h-3 w-3 mr-1" /> Live</> : 
              <><WifiOff className="h-3 w-3 mr-1" /> Offline</>
            }
          </Badge>
        </div>
        <CardDescription>
          Real-time leaderboard for the top players
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[60px]">Rank</TableHead>
              <TableHead>Player</TableHead>
              <TableHead className="text-right">Score</TableHead>
              <TableHead className="text-right">Avg. Distance</TableHead>
              <TableHead className="text-right">Time</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {leaderboard.map((session, index) => {
              const playerName = session.userId ? `Player ${session.userId}` : "Anonymous";
              
              // Handle different medals for top 3 positions
              let rankDisplay;
              if (index === 0) {
                rankDisplay = <Trophy className="h-5 w-5 text-yellow-500" />;
              } else if (index === 1) {
                rankDisplay = <Medal className="h-5 w-5 text-gray-400" />;
              } else if (index === 2) {
                rankDisplay = <Medal className="h-5 w-5 text-amber-700" />;
              } else {
                rankDisplay = index + 1;
              }
              
              return (
                <TableRow key={session.id}>
                  <TableCell className="font-medium">{rankDisplay}</TableCell>
                  <TableCell>{playerName}</TableCell>
                  <TableCell className="text-right font-bold">{formatNumber(session.totalScore || 0)}</TableCell>
                  <TableCell className="text-right">{formatNumber((session.averageDistance || 0) * 100)}%</TableCell>
                  <TableCell className="text-right whitespace-nowrap">
                    <span className="flex items-center space-x-1 justify-end">
                      <Clock className="h-3 w-3" /> 
                      <span>{formatTime(session.timeUsed || 0)}</span>
                    </span>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}