import { useCallback, useEffect, useState } from "react";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";
import { formatTime } from "@/lib/utils";
import GameMap from "./game-map";
import IframeMap from "./iframe-map";
import { GuessResult } from "@/lib/game-engine";
import { Location, Game } from "@shared/schema";
import { useRoute } from "wouter";

interface RoundResultModalProps {
  open: boolean;
  onClose: () => void;
  result: GuessResult | null;
  location: Location | null;
  mapImage: string;
  onNextRound: () => void;
  isFinalRound: boolean;
}

const RoundResultModal = ({
  open,
  onClose,
  result,
  location,
  mapImage,
  onNextRound,
  isFinalRound
}: RoundResultModalProps) => {
  const [, params] = useRoute<{ gameId: string }>("/game/:gameId");
  const gameId = params ? Number(params.gameId) : 0;
  
  const getMarkers = useCallback(() => {
    if (!result) return [];
    
    return [
      // Actual location marker (green)
      {
        x: result.actualX,
        y: result.actualY,
        color: 'rgb(16, 185, 129)', // Green color
        isUser: false
      },
      // User's guess marker (orange)
      {
        x: result.guessX,
        y: result.guessY,
        color: 'rgb(249, 115, 22)', // Orange color
        isUser: true
      }
    ];
  }, [result]);
  
  const getLines = useCallback(() => {
    if (!result) return [];
    
    return [
      {
        x1: result.actualX,
        y1: result.actualY,
        x2: result.guessX,
        y2: result.guessY,
        color: 'rgba(255, 255, 255, 0.7)'
      }
    ];
  }, [result]);
  
  if (!result || !location) return null;
  
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-card sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold font-['Orbitron'] text-center text-primary">
            Round Results
          </DialogTitle>
        </DialogHeader>
        
        {/* Result map showing both points */}
        <div className="h-64 bg-muted rounded-lg mb-6 relative">
          {gameId === 3 ? (
            /* GTA V Interactive Map */
            <IframeMap
              iframeContent='<iframe src="https://gta-5-map.com?embed=light" height="500" style="position: relative; width: 100%;"></iframe>'
              onClick={() => {}}
              disabled={false} // Allow panning and zooming in results view
              markers={getMarkers()}
            />
          ) : (
            /* Regular Game Map */
            <GameMap
              mapImage={mapImage}
              onClick={() => {}}
              markers={getMarkers()}
              lines={getLines()}
              disabled={true}
            />
          )}
        </div>
        
        {/* Result stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <Card className="bg-background">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-amber-500 mb-1">
                {result.distance}m
              </div>
              <div className="text-muted-foreground">Distance</div>
            </CardContent>
          </Card>
          <Card className="bg-background">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-primary mb-1">
                {result.score}
              </div>
              <div className="text-muted-foreground">Points</div>
            </CardContent>
          </Card>
          <Card className="bg-background">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-emerald-500 mb-1">
                {formatTime(result.timeUsed)}
              </div>
              <div className="text-muted-foreground">Time</div>
            </CardContent>
          </Card>
        </div>
        
        {/* Location info */}
        <Card className="bg-background mb-6">
          <CardContent className="p-4">
            <h4 className="font-['Orbitron'] text-lg mb-2">{location.name}</h4>
            <p className="text-muted-foreground text-sm">
              {location.description}
            </p>
          </CardContent>
        </Card>
        
        <DialogFooter className="sm:justify-center">
          <Button 
            onClick={onNextRound}
            className="bg-primary hover:bg-primary/90 text-white px-6 py-3 rounded-lg transition-colors text-lg"
          >
            {isFinalRound ? 'View Final Results' : 'Next Round'} <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default RoundResultModal;
