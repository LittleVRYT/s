import { Link } from "wouter";
import { Gamepad } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-card py-6 px-6 mt-8">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h2 className="text-xl font-bold text-primary mb-2 flex items-center">
              <Gamepad className="mr-2" />
              <span className="font-['Orbitron']">GameLocator</span>
            </h2>
            <p className="text-muted-foreground text-sm">Test your knowledge of video game worlds</p>
          </div>
          <div className="flex space-x-8">
            <div>
              <h3 className="text-foreground font-medium mb-2">Links</h3>
              <ul className="text-muted-foreground space-y-1">
                <li><Link href="/" className="hover:text-primary transition-colors">Home</Link></li>
                <li><Link href="/games" className="hover:text-primary transition-colors">Games</Link></li>
                <li><Link href="/leaderboard" className="hover:text-primary transition-colors">Leaderboard</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-foreground font-medium mb-2">Connect</h3>
              <ul className="text-muted-foreground space-y-1">
                <li><a href="#" className="hover:text-primary transition-colors">Discord</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Twitter</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Contact</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-4 border-t border-background/50 text-center text-muted-foreground text-sm">
          &copy; {new Date().getFullYear()} GameLocator. All game assets are property of their respective owners.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
