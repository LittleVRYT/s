import { useState, useEffect, useCallback } from 'react';
import { queryClient } from '@/lib/queryClient';

/**
 * Hook to connect to WebSocket for real-time leaderboard updates
 * @param gameId The ID of the game to subscribe to leaderboard updates for
 */
export function useLeaderboardSocket(gameId: number) {
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Function to create and set up the WebSocket connection
  const connectWebSocket = useCallback(() => {
    // Create WebSocket with the correct protocol based on current connection
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    // Create new WebSocket connection
    const socket = new WebSocket(wsUrl);
    
    // Set up event handlers
    socket.onopen = () => {
      setIsConnected(true);
      setError(null);
      
      // Subscribe to updates for this specific game
      socket.send(JSON.stringify({
        type: 'subscribe',
        gameId: gameId
      }));
    };
    
    socket.onclose = () => {
      setIsConnected(false);
      
      // Try to reconnect after a short delay
      setTimeout(() => connectWebSocket(), 3000);
    };
    
    socket.onerror = (event) => {
      setError('WebSocket connection error');
      setIsConnected(false);
    };
    
    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        // Handle different message types
        if (data.type === 'leaderboard_update') {
          // Invalidate the leaderboard query to trigger a refetch
          queryClient.invalidateQueries({ queryKey: [`/api/games/${gameId}/leaderboard`] });
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
    
    // Return cleanup function to close socket when component unmounts
    return () => {
      if (socket.readyState === WebSocket.OPEN) {
        socket.close();
      }
    };
  }, [gameId]);
  
  // Connect to WebSocket when component mounts
  useEffect(() => {
    const cleanup = connectWebSocket();
    return cleanup;
  }, [connectWebSocket]);
  
  return { isConnected, error };
}