import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { 
  insertGameSchema,
  insertLocationSchema,
  insertGameSessionSchema,
  insertRoundGuessSchema
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Error handler for validation errors
  const handleValidation = (validator: any, data: any) => {
    try {
      return validator.parse(data);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        throw { status: 400, message: validationError.message };
      }
      throw error;
    }
  };

  // Get all games
  app.get("/api/games", async (req, res) => {
    const games = await storage.getAllGames();
    res.json(games);
  });

  // Get a specific game
  app.get("/api/games/:id", async (req, res) => {
    const gameId = parseInt(req.params.id);
    if (isNaN(gameId)) {
      return res.status(400).json({ message: "Invalid game ID" });
    }

    const game = await storage.getGame(gameId);
    if (!game) {
      return res.status(404).json({ message: "Game not found" });
    }

    res.json(game);
  });

  // Create a new game
  app.post("/api/games", async (req, res) => {
    try {
      const gameData = handleValidation(insertGameSchema, req.body);
      const game = await storage.createGame(gameData);
      res.status(201).json(game);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Server error" });
    }
  });

  // Get locations for a game
  app.get("/api/games/:id/locations", async (req, res) => {
    const gameId = parseInt(req.params.id);
    if (isNaN(gameId)) {
      return res.status(400).json({ message: "Invalid game ID" });
    }

    const game = await storage.getGame(gameId);
    if (!game) {
      return res.status(404).json({ message: "Game not found" });
    }

    const locations = await storage.getLocationsForGame(gameId);
    res.json(locations);
  });

  // Create a new location for a game
  app.post("/api/locations", async (req, res) => {
    try {
      const locationData = handleValidation(insertLocationSchema, req.body);
      const location = await storage.createLocation(locationData);
      res.status(201).json(location);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Server error" });
    }
  });

  // Get a specific location
  app.get("/api/locations/:id", async (req, res) => {
    const locationId = parseInt(req.params.id);
    if (isNaN(locationId)) {
      return res.status(400).json({ message: "Invalid location ID" });
    }

    const location = await storage.getLocation(locationId);
    if (!location) {
      return res.status(404).json({ message: "Location not found" });
    }

    res.json(location);
  });

  // Create a new game session
  app.post("/api/sessions", async (req, res) => {
    try {
      const sessionData = handleValidation(insertGameSessionSchema, req.body);
      const session = await storage.createGameSession(sessionData);
      res.status(201).json(session);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Server error" });
    }
  });

  // Get a specific game session
  app.get("/api/sessions/:id", async (req, res) => {
    const sessionId = parseInt(req.params.id);
    if (isNaN(sessionId)) {
      return res.status(400).json({ message: "Invalid session ID" });
    }

    const session = await storage.getGameSession(sessionId);
    if (!session) {
      return res.status(404).json({ message: "Game session not found" });
    }

    res.json(session);
  });

  // Update a game session (mark as completed, etc)
  app.patch("/api/sessions/:id", async (req, res) => {
    const sessionId = parseInt(req.params.id);
    if (isNaN(sessionId)) {
      return res.status(400).json({ message: "Invalid session ID" });
    }

    const session = await storage.getGameSession(sessionId);
    if (!session) {
      return res.status(404).json({ message: "Game session not found" });
    }

    try {
      const updatedSession = await storage.updateGameSession(sessionId, req.body);
      res.json(updatedSession);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Server error" });
    }
  });

  // Submit a guess for a round
  app.post("/api/guesses", async (req, res) => {
    try {
      const guessData = handleValidation(insertRoundGuessSchema, req.body);
      
      // Verify the session exists
      const session = await storage.getGameSession(guessData.sessionId);
      if (!session) {
        return res.status(404).json({ message: "Game session not found" });
      }
      
      // Verify the location exists
      const location = await storage.getLocation(guessData.locationId);
      if (!location) {
        return res.status(404).json({ message: "Location not found" });
      }
      
      // Create the guess
      const guess = await storage.createRoundGuess(guessData);
      res.status(201).json(guess);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Server error" });
    }
  });

  // Get all guesses for a session
  app.get("/api/sessions/:id/guesses", async (req, res) => {
    const sessionId = parseInt(req.params.id);
    if (isNaN(sessionId)) {
      return res.status(400).json({ message: "Invalid session ID" });
    }

    const session = await storage.getGameSession(sessionId);
    if (!session) {
      return res.status(404).json({ message: "Game session not found" });
    }

    const guesses = await storage.getRoundGuessesForSession(sessionId);
    res.json(guesses);
  });

  // Get top scores for a game (leaderboard)
  app.get("/api/games/:id/leaderboard", async (req, res) => {
    const gameId = parseInt(req.params.id);
    if (isNaN(gameId)) {
      return res.status(400).json({ message: "Invalid game ID" });
    }

    const game = await storage.getGame(gameId);
    if (!game) {
      return res.status(404).json({ message: "Game not found" });
    }

    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const topScores = await (storage as any).getTopScores(gameId, limit);
      res.json(topScores);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Server error" });
    }
  });

  const httpServer = createServer(app);
  
  // Setup WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Connected clients by game ID
  const gameClients = new Map<number, Set<WebSocket>>();
  
  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    
    let subscribedGameId: number | null = null;
    
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Handle subscription to a game's leaderboard
        if (data.type === 'subscribe' && data.gameId) {
          subscribedGameId = data.gameId;
          
          // Add this client to the game's subscriber list
          if (!gameClients.has(data.gameId)) {
            gameClients.set(data.gameId, new Set());
          }
          gameClients.get(data.gameId)?.add(ws);
          
          // Send confirmation
          ws.send(JSON.stringify({ 
            type: 'subscribed', 
            gameId: data.gameId 
          }));
          
          console.log(`Client subscribed to game ${data.gameId}`);
        }
      } catch (err) {
        console.error('Error processing WebSocket message:', err);
      }
    });
    
    // Remove client from game subscribers when they disconnect
    ws.on('close', () => {
      if (subscribedGameId && gameClients.has(subscribedGameId)) {
        gameClients.get(subscribedGameId)?.delete(ws);
        
        // Clean up empty sets
        if (gameClients.get(subscribedGameId)?.size === 0) {
          gameClients.delete(subscribedGameId);
        }
      }
      console.log('WebSocket client disconnected');
    });
  });
  
  // Function to broadcast updates to all subscribers of a specific game
  const broadcastGameUpdate = (gameId: number, data: any) => {
    if (gameClients.has(gameId)) {
      const clients = gameClients.get(gameId)!;
      const message = JSON.stringify(data);
      
      clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(message);
        }
      });
    }
  };
  
  // Override the createRoundGuess endpoint to also broadcast updates
  const originalPost = app.post;
  app.post = function(path: string, ...handlers: any[]) {
    if (path === '/api/guesses') {
      // Replace the final handler to add broadcasting
      const finalHandler = handlers[handlers.length - 1];
      handlers[handlers.length - 1] = async (req: any, res: any) => {
        // Call the original handler
        await finalHandler(req, res);
        
        // If we get here, the guess was created successfully
        // Broadcast the leaderboard update for this game
        const guess = res.locals.guess;
        if (guess) {
          const session = await storage.getGameSession(guess.sessionId);
          if (session) {
            broadcastGameUpdate(session.gameId, {
              type: 'leaderboard_update',
              gameId: session.gameId,
              timestamp: new Date().toISOString()
            });
          }
        }
      };
    }
    
    return originalPost.call(this, path, ...handlers);
  };
  
  // Modify the /api/guesses endpoint to store the guess in res.locals
  app.post('/api/guesses', async (req, res, next) => {
    try {
      const guessData = handleValidation(insertRoundGuessSchema, req.body);
      
      // Verify the session exists
      const session = await storage.getGameSession(guessData.sessionId);
      if (!session) {
        return res.status(404).json({ message: "Game session not found" });
      }
      
      // Verify the location exists
      const location = await storage.getLocation(guessData.locationId);
      if (!location) {
        return res.status(404).json({ message: "Location not found" });
      }
      
      // Create the guess
      const guess = await storage.createRoundGuess(guessData);
      
      // Store in res.locals for the broadcast middleware
      res.locals.guess = guess;
      
      res.status(201).json(guess);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Server error" });
    }
  });
  
  // Also modify the update game session endpoint to broadcast updates when a game is completed
  app.patch('/api/sessions/:id', async (req, res) => {
    const sessionId = parseInt(req.params.id);
    if (isNaN(sessionId)) {
      return res.status(400).json({ message: "Invalid session ID" });
    }

    const session = await storage.getGameSession(sessionId);
    if (!session) {
      return res.status(404).json({ message: "Game session not found" });
    }

    try {
      const updatedSession = await storage.updateGameSession(sessionId, req.body);
      
      // If the session was marked as completed, broadcast leaderboard update
      if (req.body.completed === true) {
        broadcastGameUpdate(session.gameId, {
          type: 'leaderboard_update',
          gameId: session.gameId,
          timestamp: new Date().toISOString()
        });
      }
      
      res.json(updatedSession);
    } catch (error: any) {
      res.status(error.status || 500).json({ message: error.message || "Server error" });
    }
  });
  
  return httpServer;
}
