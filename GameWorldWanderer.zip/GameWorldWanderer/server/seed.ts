import { db } from "./db";
import { games, locations } from "@shared/schema";
import type { InsertGame, InsertLocation } from "@shared/schema";

async function seedDatabase() {
  console.log("Starting database seeding...");

  // Check if we already have data
  const existingGames = await db.select().from(games);
  if (existingGames.length > 0) {
    console.log("Database already has games. Skipping seed.");
    return;
  }

  // Sample games
  const gamesData: InsertGame[] = [
    {
      name: "The Witcher 3",
      description: "Explore the medieval fantasy world of The Witcher 3: Wild Hunt",
      coverImage: "https://via.placeholder.com/500x300?text=Witcher+3",
      genre: "RPG",
      locationCount: 5,
      rating: 4.9,
      mapImage: "https://via.placeholder.com/800x800?text=Witcher+3+Map",
    },
    {
      name: "Skyrim",
      description: "Journey through the nordic landscape of Skyrim",
      coverImage: "https://via.placeholder.com/500x300?text=Skyrim",
      genre: "RPG",
      locationCount: 5,
      rating: 4.7,
      mapImage: "https://via.placeholder.com/800x800?text=Skyrim+Map",
    },
    {
      name: "GTA V",
      description: "Navigate the sprawling metropolis of Los Santos",
      coverImage: "https://via.placeholder.com/500x300?text=GTA+V",
      genre: "Open World",
      locationCount: 5,
      rating: 4.8,
      mapImage: "https://via.placeholder.com/800x800?text=GTA+V+Map",
    }
  ];

  console.log("Inserting games...");
  // Insert games and get their IDs
  const insertedGames = await Promise.all(
    gamesData.map(async (game) => {
      const [inserted] = await db.insert(games).values(game).returning();
      return inserted;
    })
  );

  console.log(`Inserted ${insertedGames.length} games`);

  // Sample locations for Witcher 3
  const witcher3Id = insertedGames[0].id;
  const witcher3Locations: InsertLocation[] = [
    {
      gameId: witcher3Id,
      name: "Novigrad Harbor",
      description: "The main harbor of the free city of Novigrad, a bustling trade hub.",
      screenshotUrl: "https://via.placeholder.com/800x600?text=Novigrad+Harbor",
      xCoord: 0.45,
      yCoord: 0.25,
    },
    {
      gameId: witcher3Id,
      name: "Crow's Perch",
      description: "A ruined castle in Velen which serves as the seat of power for the area's self-proclaimed baron, Phillip Strenger.",
      screenshotUrl: "https://via.placeholder.com/800x600?text=Crows+Perch",
      xCoord: 0.30,
      yCoord: 0.40,
    },
    {
      gameId: witcher3Id,
      name: "Kaer Morhen",
      description: "The mountain fortress where witchers of the School of the Wolf were trained.",
      screenshotUrl: "https://via.placeholder.com/800x600?text=Kaer+Morhen",
      xCoord: 0.80,
      yCoord: 0.20,
    },
    {
      gameId: witcher3Id,
      name: "Skellige Isles",
      description: "A group of islands inhabited by skilled seafarers and fearsome warriors.",
      screenshotUrl: "https://via.placeholder.com/800x600?text=Skellige+Isles",
      xCoord: 0.15,
      yCoord: 0.70,
    },
    {
      gameId: witcher3Id,
      name: "White Orchard",
      description: "A small village in Temeria, the starting area of the game.",
      screenshotUrl: "https://via.placeholder.com/800x600?text=White+Orchard",
      xCoord: 0.60,
      yCoord: 0.50,
    }
  ];

  // Sample locations for Skyrim
  const skyrimId = insertedGames[1].id;
  const skyrimLocations: InsertLocation[] = [
    {
      gameId: skyrimId,
      name: "Whiterun",
      description: "The central trading city of Skyrim, home to the legendary Companions.",
      screenshotUrl: "https://via.placeholder.com/800x600?text=Whiterun",
      xCoord: 0.50,
      yCoord: 0.50,
    },
    {
      gameId: skyrimId,
      name: "Solitude",
      description: "The capital city of Skyrim, built on a natural arch overlooking the sea.",
      screenshotUrl: "https://via.placeholder.com/800x600?text=Solitude",
      xCoord: 0.20,
      yCoord: 0.20,
    },
    {
      gameId: skyrimId,
      name: "Winterhold College",
      description: "An ancient institution for the study of magic, perched on a cliff.",
      screenshotUrl: "https://via.placeholder.com/800x600?text=Winterhold+College",
      xCoord: 0.75,
      yCoord: 0.15,
    },
    {
      gameId: skyrimId,
      name: "Riften",
      description: "A city in the southeast corner of Skyrim, home to the Thieves Guild.",
      screenshotUrl: "https://via.placeholder.com/800x600?text=Riften",
      xCoord: 0.80,
      yCoord: 0.80,
    },
    {
      gameId: skyrimId,
      name: "High Hrothgar",
      description: "The ancient monastery near the summit of the Throat of the World.",
      screenshotUrl: "https://via.placeholder.com/800x600?text=High+Hrothgar",
      xCoord: 0.55,
      yCoord: 0.65,
    }
  ];

  // Sample locations for GTA V
  const gtaId = insertedGames[2].id;
  const gtaLocations: InsertLocation[] = [
    {
      gameId: gtaId,
      name: "Los Santos Pier",
      description: "A popular amusement park on the beach of Los Santos.",
      screenshotUrl: "https://via.placeholder.com/800x600?text=Los+Santos+Pier",
      xCoord: 0.35,
      yCoord: 0.80,
    },
    {
      gameId: gtaId,
      name: "Vinewood Sign",
      description: "The iconic hillside sign overlooking the city.",
      screenshotUrl: "https://via.placeholder.com/800x600?text=Vinewood+Sign",
      xCoord: 0.60,
      yCoord: 0.30,
    },
    {
      gameId: gtaId,
      name: "Mount Chiliad",
      description: "The highest mountain in San Andreas, popular with hikers and mountain bikers.",
      screenshotUrl: "https://via.placeholder.com/800x600?text=Mount+Chiliad",
      xCoord: 0.15,
      yCoord: 0.15,
    },
    {
      gameId: gtaId,
      name: "Maze Bank Tower",
      description: "The tallest skyscraper in Los Santos, located in the downtown area.",
      screenshotUrl: "https://via.placeholder.com/800x600?text=Maze+Bank+Tower",
      xCoord: 0.50,
      yCoord: 0.50,
    },
    {
      gameId: gtaId,
      name: "Sandy Shores",
      description: "A desert town in Blaine County, home to Trevor Phillips.",
      screenshotUrl: "https://via.placeholder.com/800x600?text=Sandy+Shores",
      xCoord: 0.75,
      yCoord: 0.25,
    }
  ];

  // Combine all locations
  const allLocations = [...witcher3Locations, ...skyrimLocations, ...gtaLocations];

  console.log("Inserting locations...");
  // Insert all locations
  const insertedLocations = await db.insert(locations).values(allLocations).returning();
  
  console.log(`Inserted ${insertedLocations.length} locations`);
  console.log("Database seeding completed successfully!");
}

export { seedDatabase };