import { 
  users, type User, type InsertUser,
  games, type Game, type InsertGame,
  locations, type Location, type InsertLocation,
  gameSessions, type GameSession, type InsertGameSession,
  roundGuesses, type RoundGuess, type InsertRoundGuess
} from "@shared/schema";

// Interface for all storage operations
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Game methods
  getAllGames(): Promise<Game[]>;
  getGame(id: number): Promise<Game | undefined>;
  createGame(game: InsertGame): Promise<Game>;
  
  // Location methods
  getLocationsForGame(gameId: number): Promise<Location[]>;
  getLocation(id: number): Promise<Location | undefined>;
  createLocation(location: InsertLocation): Promise<Location>;
  
  // Game session methods
  createGameSession(session: InsertGameSession): Promise<GameSession>;
  getGameSession(id: number): Promise<GameSession | undefined>;
  updateGameSession(id: number, data: Partial<GameSession>): Promise<GameSession | undefined>;
  
  // Round guess methods
  createRoundGuess(guess: InsertRoundGuess): Promise<RoundGuess>;
  getRoundGuessesForSession(sessionId: number): Promise<RoundGuess[]>;
  
  // Leaderboard methods
  getTopScores(gameId: number, limit?: number): Promise<GameSession[]>;
}

// In-memory implementation for development/testing
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private games: Map<number, Game>;
  private locations: Map<number, Location>;
  private gameSessions: Map<number, GameSession>;
  private roundGuesses: Map<number, RoundGuess>;
  
  private userIdCounter = 1;
  private gameIdCounter = 1;
  private locationIdCounter = 1;
  private sessionIdCounter = 1;
  private guessIdCounter = 1;

  constructor() {
    this.users = new Map();
    this.games = new Map();
    this.locations = new Map();
    this.gameSessions = new Map();
    this.roundGuesses = new Map();
    
    // Initialize with some sample games and locations
    this.seedSampleData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Game methods
  async getAllGames(): Promise<Game[]> {
    return Array.from(this.games.values());
  }
  
  async getGame(id: number): Promise<Game | undefined> {
    return this.games.get(id);
  }
  
  async createGame(game: InsertGame): Promise<Game> {
    const id = this.gameIdCounter++;
    const timestamp = new Date();
    const newGame: Game = { 
      ...game, 
      id, 
      createdAt: timestamp
    };
    this.games.set(id, newGame);
    return newGame;
  }
  
  // Location methods
  async getLocationsForGame(gameId: number): Promise<Location[]> {
    return Array.from(this.locations.values())
      .filter(location => location.gameId === gameId);
  }
  
  async getLocation(id: number): Promise<Location | undefined> {
    return this.locations.get(id);
  }
  
  async createLocation(location: InsertLocation): Promise<Location> {
    const id = this.locationIdCounter++;
    const timestamp = new Date();
    const newLocation: Location = {
      ...location,
      id,
      createdAt: timestamp
    };
    this.locations.set(id, newLocation);
    return newLocation;
  }
  
  // Game session methods
  async createGameSession(session: InsertGameSession): Promise<GameSession> {
    const id = this.sessionIdCounter++;
    const timestamp = new Date();
    const newSession: GameSession = {
      id,
      gameId: session.gameId,
      userId: session.userId || null,
      totalScore: 0,
      averageDistance: 0,
      timeUsed: 0,
      completed: false,
      createdAt: timestamp,
      completedAt: null
    };
    this.gameSessions.set(id, newSession);
    return newSession;
  }
  
  async getGameSession(id: number): Promise<GameSession | undefined> {
    return this.gameSessions.get(id);
  }
  
  async updateGameSession(id: number, data: Partial<GameSession>): Promise<GameSession | undefined> {
    const session = this.gameSessions.get(id);
    if (!session) return undefined;
    
    const updatedSession = { ...session, ...data };
    this.gameSessions.set(id, updatedSession);
    return updatedSession;
  }
  
  // Round guess methods
  async createRoundGuess(guess: InsertRoundGuess): Promise<RoundGuess> {
    const id = this.guessIdCounter++;
    const timestamp = new Date();
    const newGuess: RoundGuess = {
      ...guess,
      id,
      createdAt: timestamp
    };
    this.roundGuesses.set(id, newGuess);
    
    // Update session stats
    const sessionGuesses = await this.getRoundGuessesForSession(guess.sessionId);
    const session = await this.getGameSession(guess.sessionId);
    
    if (session) {
      const totalGuesses = sessionGuesses.length;
      const totalScore = sessionGuesses.reduce((sum, g) => sum + g.score, 0);
      const totalDistance = sessionGuesses.reduce((sum, g) => sum + g.distance, 0);
      const totalTime = sessionGuesses.reduce((sum, g) => sum + g.timeUsed, 0);
      
      await this.updateGameSession(guess.sessionId, {
        totalScore,
        averageDistance: totalDistance / totalGuesses,
        timeUsed: totalTime,
      });
    }
    
    return newGuess;
  }
  
  async getRoundGuessesForSession(sessionId: number): Promise<RoundGuess[]> {
    return Array.from(this.roundGuesses.values())
      .filter(guess => guess.sessionId === sessionId)
      .sort((a, b) => a.roundNumber - b.roundNumber);
  }
  
  async getTopScores(gameId: number, limit: number = 10): Promise<GameSession[]> {
    return Array.from(this.gameSessions.values())
      .filter(session => session.gameId === gameId && session.completed)
      .sort((a, b) => ((b.totalScore ?? 0) - (a.totalScore ?? 0)))
      .slice(0, limit);
  }
  
  // Seed data for development
  private seedSampleData() {
    // Sample games
    const games: InsertGame[] = [
      {
        name: "The Witcher 3",
        description: "Explore the medieval fantasy world of The Witcher 3: Wild Hunt",
        coverImage: "https://via.placeholder.com/500x300?text=Witcher+3",
        genre: "RPG",
        locationCount: 10,
        rating: 4.9,
        mapImage: "https://via.placeholder.com/800x800?text=Witcher+3+Map",
      },
      {
        name: "Skyrim",
        description: "Journey through the nordic landscape of Skyrim",
        coverImage: "https://via.placeholder.com/500x300?text=Skyrim",
        genre: "RPG",
        locationCount: 15,
        rating: 4.7,
        mapImage: "https://via.placeholder.com/800x800?text=Skyrim+Map",
      },
      {
        name: "GTA V",
        description: "Navigate the sprawling metropolis of Los Santos",
        coverImage: "https://via.placeholder.com/500x300?text=GTA+V",
        genre: "Open World",
        locationCount: 12,
        rating: 4.8,
        mapImage: "https://via.placeholder.com/800x800?text=GTA+V+Map",
      }
    ];
    
    // Create games
    games.forEach(game => {
      this.createGame(game);
    });
    
    // Sample locations for Witcher 3
    const witcher3Locations: InsertLocation[] = [
      {
        gameId: 1, // Witcher 3
        name: "Novigrad Harbor",
        description: "The main harbor of the free city of Novigrad, a bustling trade hub.",
        screenshotUrl: "https://via.placeholder.com/800x600?text=Novigrad+Harbor",
        xCoord: 0.45,
        yCoord: 0.25,
      },
      {
        gameId: 1,
        name: "Crow's Perch",
        description: "A ruined castle in Velen which serves as the seat of power for the area's self-proclaimed baron, Phillip Strenger.",
        screenshotUrl: "https://via.placeholder.com/800x600?text=Crows+Perch",
        xCoord: 0.30,
        yCoord: 0.40,
      },
      {
        gameId: 1,
        name: "Kaer Morhen",
        description: "The mountain fortress where witchers of the School of the Wolf were trained.",
        screenshotUrl: "https://via.placeholder.com/800x600?text=Kaer+Morhen",
        xCoord: 0.80,
        yCoord: 0.20,
      },
      {
        gameId: 1,
        name: "Skellige Isles",
        description: "A group of islands inhabited by skilled seafarers and fearsome warriors.",
        screenshotUrl: "https://via.placeholder.com/800x600?text=Skellige+Isles",
        xCoord: 0.15,
        yCoord: 0.70,
      },
      {
        gameId: 1,
        name: "White Orchard",
        description: "A small village in Temeria, the starting area of the game.",
        screenshotUrl: "https://via.placeholder.com/800x600?text=White+Orchard",
        xCoord: 0.60,
        yCoord: 0.50,
      }
    ];
    
    // Create locations
    witcher3Locations.forEach(location => {
      this.createLocation(location);
    });
  }
}

import { db } from "./db";
import { eq, asc, desc, and, sql } from "drizzle-orm";

// Database-backed implementation for production
export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  async getAllGames(): Promise<Game[]> {
    return await db.select().from(games);
  }
  
  async getGame(id: number): Promise<Game | undefined> {
    const [game] = await db.select().from(games).where(eq(games.id, id));
    return game || undefined;
  }
  
  async createGame(game: InsertGame): Promise<Game> {
    const [newGame] = await db
      .insert(games)
      .values(game)
      .returning();
    return newGame;
  }
  
  async getLocationsForGame(gameId: number): Promise<Location[]> {
    return await db
      .select()
      .from(locations)
      .where(eq(locations.gameId, gameId));
  }
  
  async getLocation(id: number): Promise<Location | undefined> {
    const [location] = await db.select().from(locations).where(eq(locations.id, id));
    return location || undefined;
  }
  
  async createLocation(location: InsertLocation): Promise<Location> {
    const [newLocation] = await db
      .insert(locations)
      .values(location)
      .returning();
    return newLocation;
  }
  
  async createGameSession(session: InsertGameSession): Promise<GameSession> {
    const [newSession] = await db
      .insert(gameSessions)
      .values(session)
      .returning();
    return newSession;
  }
  
  async getGameSession(id: number): Promise<GameSession | undefined> {
    const [session] = await db.select().from(gameSessions).where(eq(gameSessions.id, id));
    return session || undefined;
  }
  
  async updateGameSession(id: number, data: Partial<GameSession>): Promise<GameSession | undefined> {
    const [updatedSession] = await db
      .update(gameSessions)
      .set(data)
      .where(eq(gameSessions.id, id))
      .returning();
    return updatedSession || undefined;
  }
  
  async createRoundGuess(guess: InsertRoundGuess): Promise<RoundGuess> {
    const [newGuess] = await db
      .insert(roundGuesses)
      .values(guess)
      .returning();

    // Update session stats
    const sessionGuesses = await this.getRoundGuessesForSession(guess.sessionId);
    const session = await this.getGameSession(guess.sessionId);
    
    if (session) {
      const totalGuesses = sessionGuesses.length;
      const totalScore = sessionGuesses.reduce((sum, g) => sum + (g.score ?? 0), 0);
      const totalDistance = sessionGuesses.reduce((sum, g) => sum + (g.distance ?? 0), 0);
      const totalTime = sessionGuesses.reduce((sum, g) => sum + (g.timeUsed ?? 0), 0);
      
      await this.updateGameSession(guess.sessionId, {
        totalScore,
        averageDistance: totalDistance / totalGuesses,
        timeUsed: totalTime,
      });
    }
    
    return newGuess;
  }
  
  async getRoundGuessesForSession(sessionId: number): Promise<RoundGuess[]> {
    return await db
      .select()
      .from(roundGuesses)
      .where(eq(roundGuesses.sessionId, sessionId))
      .orderBy(asc(roundGuesses.roundNumber));
  }

  // Leaderboard specific methods
  async getTopScores(gameId: number, limit: number = 10): Promise<GameSession[]> {
    return await db
      .select()
      .from(gameSessions)
      .where(and(eq(gameSessions.gameId, gameId), eq(gameSessions.completed, true)))
      .orderBy(desc(gameSessions.totalScore))
      .limit(limit);
  }
}

// Use database storage
export const storage = new DatabaseStorage();
